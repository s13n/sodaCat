/*
 * Instance header file for ATSAMV70Q20B
 *
 * Copyright (c) 2026 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2025-07-21T07:57:05Z */
#ifndef _SAMV70_TC2_INSTANCE_
#define _SAMV70_TC2_INSTANCE_


/* ========== Instance Parameter definitions for TC2 peripheral ========== */
#define TC2_CLOCK_ID_CHANNEL0                    (47)
#define TC2_CLOCK_ID_CHANNEL1                    (48)
#define TC2_CLOCK_ID_CHANNEL2                    (49)
#define TC2_DMAC_ID_RX                           (42)
#define TC2_INSTANCE_ID_CHANNEL0                 (47)
#define TC2_INSTANCE_ID_CHANNEL1                 (48)
#define TC2_INSTANCE_ID_CHANNEL2                 (49)
#define TC2_NUM_INTERRUPT_LINES                  (3)
#define TC2_TCCLKS_                              (0)        /* MCK */
#define TC2_TCCLKS_TIMER_CLOCK1                  (1)        /* PCK6 */
#define TC2_TCCLKS_TIMER_CLOCK2                  (2)        /* MCK/8 */
#define TC2_TCCLKS_TIMER_CLOCK3                  (3)        /* MCK/32 */
#define TC2_TCCLKS_TIMER_CLOCK4                  (4)        /* MCK/128 */
#define TC2_TCCLKS_TIMER_CLOCK5                  (5)        /* SLCK */
#define TC2_TCCLKS_XC0                           (6)        /* XC0 */
#define TC2_TCCLKS_XC1                           (7)        /* XC1 */
#define TC2_TCCLKS_XC2                           (8)        /* XC2 */
#define TC2_TIMER_WIDTH                          (16)

#endif /* _SAMV70_TC2_INSTANCE_ */
