/*
 * Instance header file for PIC32CZ2051MC70100
 *
 * Copyright (c) 2026 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2025-07-21T08:04:26Z */
#ifndef _PIC32CZMC70_PIOC_INSTANCE_
#define _PIC32CZMC70_PIOC_INSTANCE_


/* ========== Instance Parameter definitions for PIOC peripheral ========== */
#define PIOC_CLOCK_ID                            (12)
#define PIOC_INSTANCE_ID                         (12)

#endif /* _PIC32CZMC70_PIOC_INSTANCE_ */
