# Overview

The Microchip PIC32CZ-MC70 Series Device Family Pack (DFP) is a [CMSIS-Pack](https://open-cmsis-pack.github.io/Open-CMSIS-Pack-Spec/main/html/index.html) that:

- Enables compatible tools with device support.
- Contains support files for the [MPLAB XC32 Compiler](https://www.microchip.com/en-us/tools-resources/develop/mplab-xc-compilers/xc32).
- Contains support files for the GCC compiler.
- Contains support files for the [Arm Compiler for Embedded](https://developer.arm.com/Tools%20and%20Software/Arm%20Compiler%20for%20Embedded).
- Contains support files for the [IAR Embedded Development Tools](https://www.iar.com/embedded-development-tools).
- Contains [System View Description](https://open-cmsis-pack.github.io/svd-spec/main/index.html) (SVD) descriptions of the peripherals.
- Flash algorithms for the on-chip flash memory.

## Related packs

```yml
    - pack: ARM::CMSIS
```

## Support

For support questions, contact Microchip Support through [https://www.microchip.com/en-us/support](https://www.microchip.com/en-us/support).
