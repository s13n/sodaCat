/*
 * Instance header file for ATSAMV70Q20B
 *
 * Copyright (c) 2026 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2025-07-21T07:57:05Z */
#ifndef _SAMV70_ACC_INSTANCE_
#define _SAMV70_ACC_INSTANCE_


/* ========== Instance Parameter definitions for ACC peripheral ========== */
#define ACC_CLOCK_ID                             (33)
#define ACC_HAS_CURRENT_SELECTION                (1)
#define ACC_HAS_EDGETYPE_SELECTION               (1)
#define ACC_HAS_FAULT_ENABLE                     (1)
#define ACC_HAS_HYSTERESIS                       (1)
#define ACC_HAS_INTERRUPTS                       (1)
#define ACC_HAS_INVERTED_COMPARATOR              (1)
#define ACC_HAS_MINUS_COMPARATOR_SELECTION       (1)
#define ACC_HAS_PLUS_COMPARATOR_SELECTION        (1)
#define ACC_INSTANCE_ID                          (33)

#endif /* _SAMV70_ACC_INSTANCE_ */
