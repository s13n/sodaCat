/*
 * ARMCC startup file for ATSAMV70N20B
 *
 * Copyright (c) 2026 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include "samv70n20b.h"

// Check if DeviceVectors is defined and create a typedef to VECTOR_TABLE_Type
#ifndef DEVICE_VECTORS_DEFINE
    typedef DeviceVectors VECTOR_TABLE_Type; // Defines the toolchain agnostic type of the vector table type defined in the 'samv70n20b.h'

    #define DEVICE_VECTORS_DEFINE
#endif


/*---------------------------------------------------------------------------
  External References
 *---------------------------------------------------------------------------*/
extern uint32_t __INITIAL_SP;
extern uint32_t __STACK_LIMIT;
#if defined (__ARM_FEATURE_CMSE) && (__ARM_FEATURE_CMSE == 3U)
extern uint32_t __STACK_SEAL;
#endif

extern __NO_RETURN void __PROGRAM_START(void);

/*---------------------------------------------------------------------------
  Internal References
 *---------------------------------------------------------------------------*/
__NO_RETURN void Reset_Handler  (void);
__NO_RETURN void Default_Handler(void);

/*---------------------------------------------------------------------------
  Exception / Interrupt Handler
 *---------------------------------------------------------------------------*/

/* Cortex-M7 core handlers */
void NonMaskableInt_Handler ( void ) __attribute__ ((weak, alias("Default_Handler")));
void HardFault_Handler    ( void ) __attribute__ ((weak, alias("Default_Handler")));
void MemoryManagement_Handler ( void ) __attribute__ ((weak, alias("Default_Handler")));
void BusFault_Handler     ( void ) __attribute__ ((weak, alias("Default_Handler")));
void UsageFault_Handler   ( void ) __attribute__ ((weak, alias("Default_Handler")));
void SVCall_Handler       ( void ) __attribute__ ((weak, alias("Default_Handler")));
void DebugMonitor_Handler ( void ) __attribute__ ((weak, alias("Default_Handler")));
void PendSV_Handler       ( void ) __attribute__ ((weak, alias("Default_Handler")));
void SysTick_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));

/* Peripherals handlers */
void SUPC_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void RSTC_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void RTC_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void RTT_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void WDT_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void PMC_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void EFC_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void UART0_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void UART1_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void PIOA_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void PIOB_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void USART0_Handler       ( void ) __attribute__ ((weak, alias("Default_Handler")));
void USART1_Handler       ( void ) __attribute__ ((weak, alias("Default_Handler")));
void USART2_Handler       ( void ) __attribute__ ((weak, alias("Default_Handler")));
void PIOD_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void HSMCI_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TWIHS0_Handler       ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TWIHS1_Handler       ( void ) __attribute__ ((weak, alias("Default_Handler")));
void SPI0_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void SSC_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC0_CH0_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC0_CH1_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC0_CH2_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC1_CH0_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC1_CH1_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC1_CH2_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void AFEC0_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void DACC_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void PWM0_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void ICM_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void ACC_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void USBHS_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void MCAN0_INT0_Handler   ( void ) __attribute__ ((weak, alias("Default_Handler")));
void MCAN0_INT1_Handler   ( void ) __attribute__ ((weak, alias("Default_Handler")));
void MCAN1_INT0_Handler   ( void ) __attribute__ ((weak, alias("Default_Handler")));
void MCAN1_INT1_Handler   ( void ) __attribute__ ((weak, alias("Default_Handler")));
void AFEC1_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TWIHS2_Handler       ( void ) __attribute__ ((weak, alias("Default_Handler")));
void QSPI_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void UART2_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void UART3_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void UART4_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC2_CH0_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC2_CH1_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC2_CH2_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC3_CH0_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC3_CH1_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TC3_CH2_Handler      ( void ) __attribute__ ((weak, alias("Default_Handler")));
void MLB_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void AES_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void TRNG_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void XDMAC_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void ISI_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void PWM1_Handler         ( void ) __attribute__ ((weak, alias("Default_Handler")));
void FPU_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void RSWDT_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));
void CCW_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void CCF_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void IXC_Handler          ( void ) __attribute__ ((weak, alias("Default_Handler")));
void I2SC0_Handler        ( void ) __attribute__ ((weak, alias("Default_Handler")));


/*----------------------------------------------------------------------------
  Exception / Interrupt Vector table
 *----------------------------------------------------------------------------*/

#if defined ( __GNUC__ )
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wpedantic"
#endif

extern const VECTOR_TABLE_Type __VECTOR_TABLE;
const VECTOR_TABLE_Type __VECTOR_TABLE __VECTOR_TABLE_ATTRIBUTE = {
        .pvStack = (void*) (&__INITIAL_SP),       /*     Initial Stack Pointer */



        .pfnReset_Handler              = (void*) Reset_Handler,
        .pfnNonMaskableInt_Handler     = (void*) NonMaskableInt_Handler,
        .pfnHardFault_Handler          = (void*) HardFault_Handler,
        .pfnMemoryManagement_Handler   = (void*) MemoryManagement_Handler,
        .pfnBusFault_Handler           = (void*) BusFault_Handler,
        .pfnUsageFault_Handler         = (void*) UsageFault_Handler,
        .pvReservedC9                  = (void*) (0UL), /* Reserved */
        .pvReservedC8                  = (void*) (0UL), /* Reserved */
        .pvReservedC7                  = (void*) (0UL), /* Reserved */
        .pvReservedC6                  = (void*) (0UL), /* Reserved */
        .pfnSVCall_Handler             = (void*) SVCall_Handler,
        .pfnDebugMonitor_Handler       = (void*) DebugMonitor_Handler,
        .pvReservedC3                  = (void*) (0UL), /* Reserved */
        .pfnPendSV_Handler             = (void*) PendSV_Handler,
        .pfnSysTick_Handler            = (void*) SysTick_Handler,

        /* Configurable interrupts */
        .pfnSUPC_Handler               = (void*) SUPC_Handler,   /* 0  Supply Controller */
        .pfnRSTC_Handler               = (void*) RSTC_Handler,   /* 1  Reset Controller */
        .pfnRTC_Handler                = (void*) RTC_Handler,    /* 2  Real-time Clock */
        .pfnRTT_Handler                = (void*) RTT_Handler,    /* 3  Real-time Timer */
        .pfnWDT_Handler                = (void*) WDT_Handler,    /* 4  Watchdog Timer */
        .pfnPMC_Handler                = (void*) PMC_Handler,    /* 5  Power Management Controller */
        .pfnEFC_Handler                = (void*) EFC_Handler,    /* 6  Embedded Flash Controller */
        .pfnUART0_Handler              = (void*) UART0_Handler,  /* 7  Universal Asynchronous Receiver Transmitter */
        .pfnUART1_Handler              = (void*) UART1_Handler,  /* 8  Universal Asynchronous Receiver Transmitter */
        .pvReserved9                   = (void*) (0UL),          /* 9  Reserved */
        .pfnPIOA_Handler               = (void*) PIOA_Handler,   /* 10 Parallel Input/Output Controller */
        .pfnPIOB_Handler               = (void*) PIOB_Handler,   /* 11 Parallel Input/Output Controller */
        .pvReserved12                  = (void*) (0UL),          /* 12 Reserved */
        .pfnUSART0_Handler             = (void*) USART0_Handler, /* 13 Universal Synchronous Asynchronous Receiver Transmitter */
        .pfnUSART1_Handler             = (void*) USART1_Handler, /* 14 Universal Synchronous Asynchronous Receiver Transmitter */
        .pfnUSART2_Handler             = (void*) USART2_Handler, /* 15 Universal Synchronous Asynchronous Receiver Transmitter */
        .pfnPIOD_Handler               = (void*) PIOD_Handler,   /* 16 Parallel Input/Output Controller */
        .pvReserved17                  = (void*) (0UL),          /* 17 Reserved */
        .pfnHSMCI_Handler              = (void*) HSMCI_Handler,  /* 18 High Speed MultiMedia Card Interface */
        .pfnTWIHS0_Handler             = (void*) TWIHS0_Handler, /* 19 Two-wire Interface High Speed */
        .pfnTWIHS1_Handler             = (void*) TWIHS1_Handler, /* 20 Two-wire Interface High Speed */
        .pfnSPI0_Handler               = (void*) SPI0_Handler,   /* 21 Serial Peripheral Interface */
        .pfnSSC_Handler                = (void*) SSC_Handler,    /* 22 Synchronous Serial Controller */
        .pfnTC0_CH0_Handler            = (void*) TC0_CH0_Handler, /* 23 Timer/Counter 0 Channel 0 */
        .pfnTC0_CH1_Handler            = (void*) TC0_CH1_Handler, /* 24 Timer/Counter 0 Channel 1 */
        .pfnTC0_CH2_Handler            = (void*) TC0_CH2_Handler, /* 25 Timer/Counter 0 Channel 2 */
        .pfnTC1_CH0_Handler            = (void*) TC1_CH0_Handler, /* 26 Timer/Counter 1 Channel 0 */
        .pfnTC1_CH1_Handler            = (void*) TC1_CH1_Handler, /* 27 Timer/Counter 1 Channel 1 */
        .pfnTC1_CH2_Handler            = (void*) TC1_CH2_Handler, /* 28 Timer/Counter 1 Channel 2 */
        .pfnAFEC0_Handler              = (void*) AFEC0_Handler,  /* 29 Analog Front-End Controller */
        .pfnDACC_Handler               = (void*) DACC_Handler,   /* 30 Digital-to-Analog Converter Controller */
        .pfnPWM0_Handler               = (void*) PWM0_Handler,   /* 31 Pulse Width Modulation Controller */
        .pfnICM_Handler                = (void*) ICM_Handler,    /* 32 Integrity Check Monitor */
        .pfnACC_Handler                = (void*) ACC_Handler,    /* 33 Analog Comparator Controller */
        .pfnUSBHS_Handler              = (void*) USBHS_Handler,  /* 34 USB High-Speed Interface */
        .pfnMCAN0_INT0_Handler         = (void*) MCAN0_INT0_Handler, /* 35 Controller Area Network */
        .pfnMCAN0_INT1_Handler         = (void*) MCAN0_INT1_Handler, /* 36 Controller Area Network */
        .pfnMCAN1_INT0_Handler         = (void*) MCAN1_INT0_Handler, /* 37 Controller Area Network */
        .pfnMCAN1_INT1_Handler         = (void*) MCAN1_INT1_Handler, /* 38 Controller Area Network */
        .pvReserved39                  = (void*) (0UL),          /* 39 Reserved */
        .pfnAFEC1_Handler              = (void*) AFEC1_Handler,  /* 40 Analog Front-End Controller */
        .pfnTWIHS2_Handler             = (void*) TWIHS2_Handler, /* 41 Two-wire Interface High Speed */
        .pvReserved42                  = (void*) (0UL),          /* 42 Reserved */
        .pfnQSPI_Handler               = (void*) QSPI_Handler,   /* 43 Quad Serial Peripheral Interface */
        .pfnUART2_Handler              = (void*) UART2_Handler,  /* 44 Universal Asynchronous Receiver Transmitter */
        .pfnUART3_Handler              = (void*) UART3_Handler,  /* 45 Universal Asynchronous Receiver Transmitter */
        .pfnUART4_Handler              = (void*) UART4_Handler,  /* 46 Universal Asynchronous Receiver Transmitter */
        .pfnTC2_CH0_Handler            = (void*) TC2_CH0_Handler, /* 47 Timer/Counter 2 Channel 0 */
        .pfnTC2_CH1_Handler            = (void*) TC2_CH1_Handler, /* 48 Timer/Counter 2 Channel 1 */
        .pfnTC2_CH2_Handler            = (void*) TC2_CH2_Handler, /* 49 Timer/Counter 2 Channel 2 */
        .pfnTC3_CH0_Handler            = (void*) TC3_CH0_Handler, /* 50 Timer/Counter 3 Channel 0 */
        .pfnTC3_CH1_Handler            = (void*) TC3_CH1_Handler, /* 51 Timer/Counter 3 Channel 1 */
        .pfnTC3_CH2_Handler            = (void*) TC3_CH2_Handler, /* 52 Timer/Counter 3 Channel 2 */
        .pfnMLB_Handler                = (void*) MLB_Handler,    /* 53 MediaLB */
        .pvReserved54                  = (void*) (0UL),          /* 54 Reserved */
        .pvReserved55                  = (void*) (0UL),          /* 55 Reserved */
        .pfnAES_Handler                = (void*) AES_Handler,    /* 56 Advanced Encryption Standard */
        .pfnTRNG_Handler               = (void*) TRNG_Handler,   /* 57 True Random Number Generator */
        .pfnXDMAC_Handler              = (void*) XDMAC_Handler,  /* 58 Extensible DMA Controller */
        .pfnISI_Handler                = (void*) ISI_Handler,    /* 59 Image Sensor Interface */
        .pfnPWM1_Handler               = (void*) PWM1_Handler,   /* 60 Pulse Width Modulation Controller */
        .pfnFPU_Handler                = (void*) FPU_Handler,    /* 61 Floating Point Unit */
        .pvReserved62                  = (void*) (0UL),          /* 62 Reserved */
        .pfnRSWDT_Handler              = (void*) RSWDT_Handler,  /* 63 Reinforced Safety Watchdog Timer */
        .pfnCCW_Handler                = (void*) CCW_Handler,    /* 64 System Control Block */
        .pfnCCF_Handler                = (void*) CCF_Handler,    /* 65 System Control Block */
        .pvReserved66                  = (void*) (0UL),          /* 66 Reserved */
        .pvReserved67                  = (void*) (0UL),          /* 67 Reserved */
        .pfnIXC_Handler                = (void*) IXC_Handler,    /* 68 Floating Point Unit */
        .pfnI2SC0_Handler              = (void*) I2SC0_Handler   /* 69 Inter-IC Sound Controller */
};

#if defined ( __GNUC__ )
    #pragma GCC diagnostic pop
#endif

/*----------------------------------------------------------------------------
  Reset Handler called on controller reset
 *----------------------------------------------------------------------------*/
__NO_RETURN void Reset_Handler(void)
{
    #if !defined(DISABLE_CMSIS_INIT)
    SystemInit();           /* CMSIS System Initialization */
    #endif /* DISABLE_CMSIS_INIT */

    /* Branch to main function */
    __PROGRAM_START();      /* Enter PreMain (C library entry point) */
}

#if defined(__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Wmissing-noreturn"
#endif

/*----------------------------------------------------------------------------
  Default Handler for Exceptions / Interrupts
 *----------------------------------------------------------------------------*/
void Default_Handler(void)
{
    while (1);
}

#if defined(__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
    #pragma clang diagnostic pop
#endif
