/*
 * Instance header file for ATSAMV70Q20B
 *
 * Copyright (c) 2026 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2025-07-21T07:57:05Z */
#ifndef _SAMV70_SSC_INSTANCE_
#define _SAMV70_SSC_INSTANCE_


/* ========== Instance Parameter definitions for SSC peripheral ========== */
#define SSC_CLOCK_ID                             (22)
#define SSC_DMAC_ID_RX                           (33)
#define SSC_DMAC_ID_TX                           (32)
#define SSC_INSTANCE_ID                          (22)

#endif /* _SAMV70_SSC_INSTANCE_ */
