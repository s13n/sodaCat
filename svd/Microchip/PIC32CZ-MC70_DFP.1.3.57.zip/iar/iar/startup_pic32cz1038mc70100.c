/*
 * IAR startup file for PIC32CZ1038MC70100
 *
 * Copyright (c) 2026 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include "pic32cz1038mc70100.h"

typedef void (*intfunc) (void);
typedef union { intfunc __fun; void * __ptr; } intvec_elem;

void __iar_program_start(void);
int __low_level_init(void);

/* Reset handler */
void Reset_Handler(void);

/* Default empty handler */
void Default_Handler(void);

/* Cortex-M7 core handlers */
#pragma weak NMI_Handler=Default_Handler
#pragma weak HardFault_Handler=Default_Handler
#pragma weak MemManage_Handler=Default_Handler
#pragma weak BusFault_Handler=Default_Handler
#pragma weak UsageFault_Handler=Default_Handler
#pragma weak SVC_Handler=Default_Handler
#pragma weak DebugMon_Handler=Default_Handler
#pragma weak PendSV_Handler=Default_Handler
#pragma weak SysTick_Handler=Default_Handler

/* Peripherals handlers */
#pragma weak SUPC_Handler=Default_Handler
#pragma weak RSTC_Handler=Default_Handler
#pragma weak RTC_Handler=Default_Handler
#pragma weak RTT_Handler=Default_Handler
#pragma weak WDT_Handler=Default_Handler
#pragma weak PMC_Handler=Default_Handler
#pragma weak EFC_Handler=Default_Handler
#pragma weak UART0_Handler=Default_Handler
#pragma weak UART1_Handler=Default_Handler
#pragma weak PIOA_Handler=Default_Handler
#pragma weak PIOB_Handler=Default_Handler
#pragma weak USART0_Handler=Default_Handler
#pragma weak USART1_Handler=Default_Handler
#pragma weak USART2_Handler=Default_Handler
#pragma weak PIOD_Handler=Default_Handler
#pragma weak HSMCI_Handler=Default_Handler
#pragma weak TWIHS0_Handler=Default_Handler
#pragma weak TWIHS1_Handler=Default_Handler
#pragma weak SPI0_Handler=Default_Handler
#pragma weak SSC_Handler=Default_Handler
#pragma weak TC0_CH0_Handler=Default_Handler
#pragma weak TC0_CH1_Handler=Default_Handler
#pragma weak TC0_CH2_Handler=Default_Handler
#pragma weak TC1_CH0_Handler=Default_Handler
#pragma weak TC1_CH1_Handler=Default_Handler
#pragma weak TC1_CH2_Handler=Default_Handler
#pragma weak AFEC0_Handler=Default_Handler
#pragma weak DACC_Handler=Default_Handler
#pragma weak PWM0_Handler=Default_Handler
#pragma weak ICM_Handler=Default_Handler
#pragma weak ACC_Handler=Default_Handler
#pragma weak USBHS_Handler=Default_Handler
#pragma weak MCAN0_INT0_Handler=Default_Handler
#pragma weak MCAN0_INT1_Handler=Default_Handler
#pragma weak MCAN1_INT0_Handler=Default_Handler
#pragma weak MCAN1_INT1_Handler=Default_Handler
#pragma weak AFEC1_Handler=Default_Handler
#pragma weak TWIHS2_Handler=Default_Handler
#pragma weak QSPI_Handler=Default_Handler
#pragma weak UART2_Handler=Default_Handler
#pragma weak UART3_Handler=Default_Handler
#pragma weak UART4_Handler=Default_Handler
#pragma weak TC2_CH0_Handler=Default_Handler
#pragma weak TC2_CH1_Handler=Default_Handler
#pragma weak TC2_CH2_Handler=Default_Handler
#pragma weak TC3_CH0_Handler=Default_Handler
#pragma weak TC3_CH1_Handler=Default_Handler
#pragma weak TC3_CH2_Handler=Default_Handler
#pragma weak MLB_Handler=Default_Handler
#pragma weak AES_Handler=Default_Handler
#pragma weak TRNG_Handler=Default_Handler
#pragma weak XDMAC_Handler=Default_Handler
#pragma weak ISI_Handler=Default_Handler
#pragma weak PWM1_Handler=Default_Handler
#pragma weak FPU_Handler=Default_Handler
#pragma weak RSWDT_Handler=Default_Handler
#pragma weak CCW_Handler=Default_Handler
#pragma weak CCF_Handler=Default_Handler
#pragma weak IXC_Handler=Default_Handler
#pragma weak I2SC0_Handler=Default_Handler

/* Exception Table */
#pragma language = extended
#pragma segment = "CSTACK"

/* The name "__vector_table" has special meaning for C-SPY: */
/* it is where the SP start value is found, and the NVIC vector */
/* table register (VTOR) is initialized to this address if != 0 */

#pragma section = ".intvec"
#pragma location = ".intvec"
const DeviceVectors __vector_table = {
        (void*) __sfe("CSTACK"),



        .pfnReset_Handler              = (void*) Reset_Handler,
        .pfnNMI_Handler                = (void*) NMI_Handler,
        .pfnHardFault_Handler          = (void*) HardFault_Handler,
        .pfnMemManage_Handler          = (void*) MemManage_Handler,
        .pfnBusFault_Handler           = (void*) BusFault_Handler,
        .pfnUsageFault_Handler         = (void*) UsageFault_Handler,
        .pvReservedC9                  = (void*) (0UL), /* Reserved */
        .pvReservedC8                  = (void*) (0UL), /* Reserved */
        .pvReservedC7                  = (void*) (0UL), /* Reserved */
        .pvReservedC6                  = (void*) (0UL), /* Reserved */
        .pfnSVC_Handler                = (void*) SVC_Handler,
        .pfnDebugMon_Handler           = (void*) DebugMon_Handler,
        .pvReservedC3                  = (void*) (0UL), /* Reserved */
        .pfnPendSV_Handler             = (void*) PendSV_Handler,
        .pfnSysTick_Handler            = (void*) SysTick_Handler,

        /* Configurable interrupts */
        .pfnSUPC_Handler               = (void*) SUPC_Handler,   /* 0  Supply Controller */
        .pfnRSTC_Handler               = (void*) RSTC_Handler,   /* 1  Reset Controller */
        .pfnRTC_Handler                = (void*) RTC_Handler,    /* 2  Real-time Clock */
        .pfnRTT_Handler                = (void*) RTT_Handler,    /* 3  Real-time Timer */
        .pfnWDT_Handler                = (void*) WDT_Handler,    /* 4  Watchdog Timer */
        .pfnPMC_Handler                = (void*) PMC_Handler,    /* 5  Power Management Controller */
        .pfnEFC_Handler                = (void*) EFC_Handler,    /* 6  Embedded Flash Controller */
        .pfnUART0_Handler              = (void*) UART0_Handler,  /* 7  Universal Asynchronous Receiver Transmitter */
        .pfnUART1_Handler              = (void*) UART1_Handler,  /* 8  Universal Asynchronous Receiver Transmitter */
        .pvReserved9                   = (void*) (0UL),          /* 9  Reserved */
        .pfnPIOA_Handler               = (void*) PIOA_Handler,   /* 10 Parallel Input/Output Controller */
        .pfnPIOB_Handler               = (void*) PIOB_Handler,   /* 11 Parallel Input/Output Controller */
        .pvReserved12                  = (void*) (0UL),          /* 12 Reserved */
        .pfnUSART0_Handler             = (void*) USART0_Handler, /* 13 Universal Synchronous Asynchronous Receiver Transmitter */
        .pfnUSART1_Handler             = (void*) USART1_Handler, /* 14 Universal Synchronous Asynchronous Receiver Transmitter */
        .pfnUSART2_Handler             = (void*) USART2_Handler, /* 15 Universal Synchronous Asynchronous Receiver Transmitter */
        .pfnPIOD_Handler               = (void*) PIOD_Handler,   /* 16 Parallel Input/Output Controller */
        .pvReserved17                  = (void*) (0UL),          /* 17 Reserved */
        .pfnHSMCI_Handler              = (void*) HSMCI_Handler,  /* 18 High Speed MultiMedia Card Interface */
        .pfnTWIHS0_Handler             = (void*) TWIHS0_Handler, /* 19 Two-wire Interface High Speed */
        .pfnTWIHS1_Handler             = (void*) TWIHS1_Handler, /* 20 Two-wire Interface High Speed */
        .pfnSPI0_Handler               = (void*) SPI0_Handler,   /* 21 Serial Peripheral Interface */
        .pfnSSC_Handler                = (void*) SSC_Handler,    /* 22 Synchronous Serial Controller */
        .pfnTC0_CH0_Handler            = (void*) TC0_CH0_Handler, /* 23 Timer/Counter 0 Channel 0 */
        .pfnTC0_CH1_Handler            = (void*) TC0_CH1_Handler, /* 24 Timer/Counter 0 Channel 1 */
        .pfnTC0_CH2_Handler            = (void*) TC0_CH2_Handler, /* 25 Timer/Counter 0 Channel 2 */
        .pfnTC1_CH0_Handler            = (void*) TC1_CH0_Handler, /* 26 Timer/Counter 1 Channel 0 */
        .pfnTC1_CH1_Handler            = (void*) TC1_CH1_Handler, /* 27 Timer/Counter 1 Channel 1 */
        .pfnTC1_CH2_Handler            = (void*) TC1_CH2_Handler, /* 28 Timer/Counter 1 Channel 2 */
        .pfnAFEC0_Handler              = (void*) AFEC0_Handler,  /* 29 Analog Front-End Controller */
        .pfnDACC_Handler               = (void*) DACC_Handler,   /* 30 Digital-to-Analog Converter Controller */
        .pfnPWM0_Handler               = (void*) PWM0_Handler,   /* 31 Pulse Width Modulation Controller */
        .pfnICM_Handler                = (void*) ICM_Handler,    /* 32 Integrity Check Monitor */
        .pfnACC_Handler                = (void*) ACC_Handler,    /* 33 Analog Comparator Controller */
        .pfnUSBHS_Handler              = (void*) USBHS_Handler,  /* 34 USB High-Speed Interface */
        .pfnMCAN0_INT0_Handler         = (void*) MCAN0_INT0_Handler, /* 35 Controller Area Network */
        .pfnMCAN0_INT1_Handler         = (void*) MCAN0_INT1_Handler, /* 36 Controller Area Network */
        .pfnMCAN1_INT0_Handler         = (void*) MCAN1_INT0_Handler, /* 37 Controller Area Network */
        .pfnMCAN1_INT1_Handler         = (void*) MCAN1_INT1_Handler, /* 38 Controller Area Network */
        .pvReserved39                  = (void*) (0UL),          /* 39 Reserved */
        .pfnAFEC1_Handler              = (void*) AFEC1_Handler,  /* 40 Analog Front-End Controller */
        .pfnTWIHS2_Handler             = (void*) TWIHS2_Handler, /* 41 Two-wire Interface High Speed */
        .pvReserved42                  = (void*) (0UL),          /* 42 Reserved */
        .pfnQSPI_Handler               = (void*) QSPI_Handler,   /* 43 Quad Serial Peripheral Interface */
        .pfnUART2_Handler              = (void*) UART2_Handler,  /* 44 Universal Asynchronous Receiver Transmitter */
        .pfnUART3_Handler              = (void*) UART3_Handler,  /* 45 Universal Asynchronous Receiver Transmitter */
        .pfnUART4_Handler              = (void*) UART4_Handler,  /* 46 Universal Asynchronous Receiver Transmitter */
        .pfnTC2_CH0_Handler            = (void*) TC2_CH0_Handler, /* 47 Timer/Counter 2 Channel 0 */
        .pfnTC2_CH1_Handler            = (void*) TC2_CH1_Handler, /* 48 Timer/Counter 2 Channel 1 */
        .pfnTC2_CH2_Handler            = (void*) TC2_CH2_Handler, /* 49 Timer/Counter 2 Channel 2 */
        .pfnTC3_CH0_Handler            = (void*) TC3_CH0_Handler, /* 50 Timer/Counter 3 Channel 0 */
        .pfnTC3_CH1_Handler            = (void*) TC3_CH1_Handler, /* 51 Timer/Counter 3 Channel 1 */
        .pfnTC3_CH2_Handler            = (void*) TC3_CH2_Handler, /* 52 Timer/Counter 3 Channel 2 */
        .pfnMLB_Handler                = (void*) MLB_Handler,    /* 53 MediaLB */
        .pvReserved54                  = (void*) (0UL),          /* 54 Reserved */
        .pvReserved55                  = (void*) (0UL),          /* 55 Reserved */
        .pfnAES_Handler                = (void*) AES_Handler,    /* 56 Advanced Encryption Standard */
        .pfnTRNG_Handler               = (void*) TRNG_Handler,   /* 57 True Random Number Generator */
        .pfnXDMAC_Handler              = (void*) XDMAC_Handler,  /* 58 Extensible DMA Controller */
        .pfnISI_Handler                = (void*) ISI_Handler,    /* 59 Image Sensor Interface */
        .pfnPWM1_Handler               = (void*) PWM1_Handler,   /* 60 Pulse Width Modulation Controller */
        .pfnFPU_Handler                = (void*) FPU_Handler,    /* 61 Floating Point Unit */
        .pvReserved62                  = (void*) (0UL),          /* 62 Reserved */
        .pfnRSWDT_Handler              = (void*) RSWDT_Handler,  /* 63 Reinforced Safety Watchdog Timer */
        .pfnCCW_Handler                = (void*) CCW_Handler,    /* 64 System Control Block */
        .pfnCCF_Handler                = (void*) CCF_Handler,    /* 65 System Control Block */
        .pvReserved66                  = (void*) (0UL),          /* 66 Reserved */
        .pvReserved67                  = (void*) (0UL),          /* 67 Reserved */
        .pfnIXC_Handler                = (void*) IXC_Handler,    /* 68 Floating Point Unit */
        .pfnI2SC0_Handler              = (void*) I2SC0_Handler   /* 69 Inter-IC Sound Controller */
};

/**------------------------------------------------------------------------------
 * This is the code that gets called on processor reset. To initialize the
 * device.
 *------------------------------------------------------------------------------*/
int __low_level_init(void)
{
        uint32_t *pSrc = __section_begin(".intvec");

        SCB->VTOR = ((uint32_t) pSrc & SCB_VTOR_TBLOFF_Msk);

        return 1; /* if return 0, the data sections will not be initialized */
}

/**------------------------------------------------------------------------------
 * This is the code that gets called on processor reset. To initialize the
 * device.
 *------------------------------------------------------------------------------*/
void Reset_Handler(void)
{
        __iar_program_start();
}

/**
 * \brief Default interrupt handler for unused IRQs.
 */
void Default_Handler(void)
{
        while (1) {
        }
}
