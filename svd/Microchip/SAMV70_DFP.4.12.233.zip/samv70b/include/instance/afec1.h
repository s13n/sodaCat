/*
 * Instance header file for ATSAMV70Q20B
 *
 * Copyright (c) 2026 Microchip Technology Inc. and its subsidiaries.
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

/* file generated from device description file (ATDF) version 2025-07-21T07:57:05Z */
#ifndef _SAMV70_AFEC1_INSTANCE_
#define _SAMV70_AFEC1_INSTANCE_


/* ========== Instance Parameter definitions for AFEC1 peripheral ========== */
#define AFEC1_CLOCK_ID                           (40)
#define AFEC1_DMAC_ID_RX                         (36)
#define AFEC1_INSTANCE_ID                        (40)
#define AFEC1_TRGSEL_AFEC_TRIG0                  (0x0)      /* External ADC Trigger Input (AFE1_ADTRG Pin) */
#define AFEC1_TRGSEL_AFEC_TRIG1                  (0x1)      /* TC1 Channel 0 Output (TIOA3) */
#define AFEC1_TRGSEL_AFEC_TRIG2                  (0x2)      /* TC1 Channel 1 Output (TIOA4) */
#define AFEC1_TRGSEL_AFEC_TRIG3                  (0x3)      /* TC1 Channel 2 Output (TIOA5) */
#define AFEC1_TRGSEL_AFEC_TRIG4                  (0x4)      /* PWM1 event line 0 */
#define AFEC1_TRGSEL_AFEC_TRIG5                  (0x5)      /* PWM1 event line 1 */
#define AFEC1_TRGSEL_AFEC_TRIG6                  (0x6)      /* Analog Comparator Fault Output */

#endif /* _SAMV70_AFEC1_INSTANCE_ */
